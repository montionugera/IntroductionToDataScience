1. The RMD file containing the analysis  : RedwineQuality.Rmd
2. the HTML file knitted from the RMD file using the knitr package :  RedwineQuality.html

N/A